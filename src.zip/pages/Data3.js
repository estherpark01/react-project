import React from 'react';
import {Routes, Route, NavLink} from 'react-router-dom';
import * as S from "../Styled";
import '../subcss/Data.css';

function Data3() {

}

  export default Data3;