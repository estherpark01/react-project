import React from 'react';
import * as S from "../Styled";
import '../subcss/Position.css'


function Position3() {
    return (
        <div>           
            <h3 className='hidden'>기후서비스</h3>
            <div className='commonTit'>
                <p>주요 업무</p>
            </div>
        </div>
    
    );
  }

export default Position3;